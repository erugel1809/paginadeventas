import HeroScrollDemo from "@/components/container-scroll-animation-demo"

export default function Page() {
  return (
    <main className="min-h-screen">
      <HeroScrollDemo />
    </main>
  )
}
